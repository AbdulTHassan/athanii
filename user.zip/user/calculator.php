<?php
// user/calculator.php
$pageTitle = 'Calculate Zakat';

// 1. Haɗa muhimman fayiloli (Gyara currentUser() error)
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

// 2. Duba idan mutum bai shiga ba (Security Check)
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit;
}

// 3. Haɗa Header na Dashboard
require_once '_header.php';

// 4. Ɗauko nau'in lissafin
$type = $_GET['type'] ?? 'cash';
$animal = $_GET['animal'] ?? 'cow';
?>

<!-- Dashboard Layout Wrapper -->
<div class="flex min-h-screen bg-gray-50">

    <!-- SIDEBAR NA DASHBOARD (Daga user/_sidebar.php) -->
    <div class="w-64 bg-white border-r border-gray-200 hidden md:block">
        <?php require_once '_sidebar.php'; ?>
    </div>

    <!-- MAIN CONTENT AREA -->
    <div class="flex-1 flex flex-col">
        
        <!-- HEADER NA DASHBOARD (An riga an saka shi a sama) -->

        <main class="flex-1 p-6">
            <div class="max-w-6xl mx-auto">

                <!-- Page Title -->
                <div class="mb-6">
                    <h1 class="text-2xl font-bold text-gray-800">Zakat Calculator</h1>
                    <p class="text-sm text-gray-500">Select a category below to calculate your Zakat.</p>
                </div>

                <!-- TABS (Maimakon Sidebar na public) -->
                <div class="flex flex-wrap gap-2 mb-6 border-b border-gray-200 pb-4">
                    <a href="?type=cash" class="px-4 py-2 rounded-lg text-sm font-medium <?= $type === 'cash' ? 'bg-green-700 text-white' : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50' ?>">
                        <i class="fas fa-money-bill-wave mr-2"></i> Cash
                    </a>
                    <a href="?type=gold_silver" class="px-4 py-2 rounded-lg text-sm font-medium <?= $type === 'gold_silver' ? 'bg-green-700 text-white' : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50' ?>">
                        <i class="fas fa-coins mr-2"></i> Gold & Silver
                    </a>
                    <a href="?type=properties" class="px-4 py-2 rounded-lg text-sm font-medium <?= $type === 'properties' ? 'bg-green-700 text-white' : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50' ?>">
                        <i class="fas fa-building mr-2"></i> Business / Property
                    </a>
                    <a href="?type=agriculture" class="px-4 py-2 rounded-lg text-sm font-medium <?= $type === 'agriculture' ? 'bg-green-700 text-white' : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50' ?>">
                        <i class="fas fa-seedling mr-2"></i> Agriculture
                    </a>
                    <a href="?type=livestock&animal=goat" class="px-4 py-2 rounded-lg text-sm font-medium <?= ($type === 'livestock' && $animal === 'goat') ? 'bg-green-700 text-white' : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50' ?>">
                        <i class="fas fa-paw mr-2"></i> Goats
                    </a>
                    <a href="?type=livestock&animal=cow" class="px-4 py-2 rounded-lg text-sm font-medium <?= ($type === 'livestock' && $animal === 'cow') ? 'bg-green-700 text-white' : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50' ?>">
                        <i class="fas fa-cow mr-2"></i> Cows
                    </a>
                    <a href="?type=livestock&animal=camel" class="px-4 py-2 rounded-lg text-sm font-medium <?= ($type === 'livestock' && $animal === 'camel') ? 'bg-green-700 text-white' : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50' ?>">
                        <i class="fas fa-horse mr-2"></i> Camels
                    </a>
                </div>

                <!-- COMPONENT LOADER -->
                <div class="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
                    <?php
                    // Nan ne za mu shigo da injin ɗin lissafin daga calculator/component/
                    if ($type === 'cash') {
                        include __DIR__ . '/../calculator/component/cash.php';
                    } elseif ($type === 'gold_silver') {
                        include __DIR__ . '/../calculator/component/gold_silver.php';
                    } elseif ($type === 'properties') {
                        include __DIR__ . '/../calculator/component/properties.php';
                    } elseif ($type === 'agriculture') {
                        include __DIR__ . '/../calculator/component/agriculture.php';
                    } elseif ($type === 'livestock') {
                        include __DIR__ . '/../calculator/component/livestock.php';
                    } else {
                        echo '<div class="text-center text-gray-500 py-10">Select a calculator from the tabs above.</div>';
                    }
                    ?>
                </div>

            </div>
        </main>
    </div>
</div>

<?php require_once '_footer.php'; ?>