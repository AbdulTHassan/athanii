<?php
// auth/register.php
require_once __DIR__ . '/../config/config.php';

if (isLoggedIn()) {
    $role = (int)($_SESSION['role_id'] ?? 0);
    redirect($role === 1 
        ? SITE_URL . '/admin/index.php' 
        : SITE_URL . '/user/dashboard.php');
}

$error = '';
$formData = ['full_name' => '', 'email' => '', 'phone' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['full_name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $phone    = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';
    
    $formData = ['full_name' => $name, 'email' => $email, 'phone' => $phone];
    
    if ($name === '' || $email === '' || $password === '' || $confirm === '') {
        $error = MSG_FILL_ALL_FIELDS;
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = MSG_INVALID_EMAIL;
    } elseif (strlen($password) < 8) {
        $error = MSG_PASSWORD_TOO_SHORT;
    } elseif (!preg_match('/[a-z]/', $password)) {
        $error = 'Password must contain at least one lowercase letter.';
    } elseif (!preg_match('/[A-Z]/', $password)) {
        $error = 'Password must contain at least one uppercase letter.';
    } elseif (!preg_match('/[0-9]/', $password)) {
        $error = 'Password must contain at least one number.';
    } elseif ($password !== $confirm) {
        $error = MSG_PASSWORD_MISMATCH;
    } else {
        $st = $pdo->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
        $st->execute([$email]);
        
        if ($st->fetch()) {
            $error = MSG_EMAIL_TAKEN;
        } else {
            try {
                $pdo->beginTransaction();
                
                $verificationToken = bin2hex(random_bytes(32));
                
                $st = $pdo->prepare("
                    INSERT INTO users (role_id, full_name, email, phone, password, status, verification_token)
                    VALUES (2, ?, ?, ?, ?, 'active', ?)
                ");
                $st->execute([
                    $name, $email, $phone ?: null,
                    password_hash($password, PASSWORD_DEFAULT),
                    $verificationToken
                ]);
                $userId = (int)$pdo->lastInsertId();
                
                $expiresAt = date('Y-m-d H:i:s', time() + 86400);
                $pdo->prepare("
                    INSERT INTO email_verifications (user_id, email, token, expires_at)
                    VALUES (?, ?, ?, ?)
                ")->execute([$userId, $email, $verificationToken, $expiresAt]);
                
                $verifyLink = SITE_URL . '/auth/verify.php?token=' . $verificationToken;
                $body = emailTemplateVerify($name, $verifyLink);
                sendEmail($email, 'Verify Your Email - ' . SITE_NAME, $body);
                
                markVisitorConverted($userId);
                logActivity($userId, 'registered', null, 'New user registered');
                
                session_regenerate_id(true);
                $_SESSION['user_id']       = $userId;
                $_SESSION['role_id']       = 2;
                $_SESSION['full_name']     = $name;
                $_SESSION['email']         = $email;
                $_SESSION['language']      = 'en';
                $_SESSION['last_activity'] = time();
                
                $pdo->commit();
                
                redirect(SITE_URL . '/user/dashboard.php');
                
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = MSG_ERROR_OCCURRED;
            }
        }
    }
}

ob_start();
?>
<div class="text-center mb-6">
    <div class="inline-flex items-center justify-center w-16 h-16 
                bg-gradient-to-br from-green-600 to-green-800 rounded-2xl shadow-lg mb-3">
        <i class="fas fa-user-plus text-white text-2xl"></i>
    </div>
    <h1 class="text-2xl font-bold text-gray-800"><?php _e('create_account'); ?></h1>
    <p class="text-gray-500 text-sm mt-1"><?php _e('register_subtitle'); ?></p>
</div>

<?php if ($error): ?>
<div class="bg-red-50 border-l-4 border-red-500 text-red-700 p-3 rounded-lg mb-4 flex items-start gap-2">
    <i class="fas fa-exclamation-circle mt-0.5"></i>
    <span class="text-sm"><?php echo e($error); ?></span>
</div>
<?php endif; ?>

<form method="POST" class="space-y-4" 
      onsubmit="return validatePassword('password') && checkPasswordMatch2('password', 'confirm_password')">
    
    <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1.5"><?php _e('full_name'); ?></label>
        <div class="relative">
            <span class="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-sm">
                <i class="fas fa-user"></i>
            </span>
            <input type="text" name="full_name" required autofocus
                   value="<?php echo e($formData['full_name']); ?>"
                   class="w-full pl-11 pr-4 py-3 border-2 border-gray-200 rounded-xl 
                          focus:border-green-500 focus:outline-none text-gray-800 text-sm"
                   placeholder="Your full name">
        </div>
    </div>

    <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1.5"><?php _e('email_address'); ?></label>
        <div class="relative">
            <span class="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-sm">
                <i class="fas fa-envelope"></i>
            </span>
            <input type="email" name="email" required
                   value="<?php echo e($formData['email']); ?>"
                   class="w-full pl-11 pr-4 py-3 border-2 border-gray-200 rounded-xl 
                          focus:border-green-500 focus:outline-none text-gray-800 text-sm"
                   placeholder="you@example.com">
        </div>
    </div>

    <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1.5"><?php _e('phone_optional'); ?></label>
        <div class="relative">
            <span class="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-sm">
                <i class="fas fa-phone"></i>
            </span>
            <input type="text" name="phone"
                   value="<?php echo e($formData['phone']); ?>"
                   class="w-full pl-11 pr-4 py-3 border-2 border-gray-200 rounded-xl 
                          focus:border-green-500 focus:outline-none text-gray-800 text-sm"
                   placeholder="+234...">
        </div>
    </div>

    <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1.5"><?php _e('password'); ?></label>
        <div class="relative">
            <span class="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-sm">
                <i class="fas fa-lock"></i>
            </span>
            <input type="password" name="password" id="password" required minlength="8"
                   class="w-full pl-11 pr-11 py-3 border-2 border-gray-200 rounded-xl 
                          focus:border-green-500 focus:outline-none text-gray-800 text-sm"
                   placeholder="At least 8 characters">
            <button type="button" 
                    onclick="togglePassword('password', 'toggleIcon1')"
                    class="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                <i class="fas fa-eye" id="toggleIcon1"></i>
            </button>
        </div>
        
        <div class="h-1 bg-gray-200 rounded-full mt-2 overflow-hidden">
            <div id="password-bar" class="h-1 w-0 transition-all rounded-full"></div>
        </div>
        <p id="password-text" class="text-xs mt-1"></p>
        
        <div class="mt-2 text-xs text-gray-500 space-y-1">
            <p class="font-semibold"><i class="fas fa-info-circle text-blue-500"></i> Password requirements:</p>
            <ul class="ml-4 space-y-0.5">
                <li>✅ At least 8 characters</li>
                <li>✅ At least 1 lowercase letter (a-z)</li>
                <li>✅ At least 1 uppercase letter (A-Z)</li>
                <li>✅ At least 1 number (0-9)</li>
                <li>💡 Add special character (!@#$) for stronger password</li>
            </ul>
        </div>
    </div>

    <div>
        <label class="block text-sm font-semibold text-gray-700 mb-1.5"><?php _e('confirm_password'); ?></label>
        <div class="relative">
            <span class="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-sm">
                <i class="fas fa-lock"></i>
            </span>
            <input type="password" name="confirm_password" id="confirm_password" required minlength="8"
                   class="w-full pl-11 pr-4 py-3 border-2 border-gray-200 rounded-xl 
                          focus:border-green-500 focus:outline-none text-gray-800 text-sm"
                   placeholder="Re-enter password">
        </div>
        <p id="match-indicator" class="text-xs mt-1"></p>
    </div>

    <button type="submit"
            class="w-full bg-gradient-to-r from-green-700 to-green-800 
                   hover:from-green-800 hover:to-green-900 text-white py-3.5 
                   rounded-xl font-bold text-base transition-all duration-300 
                   transform hover:scale-[1.02] shadow-lg">
        <i class="fas fa-user-plus mr-2"></i> <?php _e('create_account'); ?>
    </button>
</form>

<p class="text-center text-sm text-gray-600 mt-6">
    <?php _e('already_have_account'); ?>
    <a href="login.php" class="text-green-700 font-bold hover:underline"><?php _e('sign_in'); ?></a>
</p>
<?php
$content = ob_get_clean();
?>
<!DOCTYPE html>
<html lang="<?php echo currentLanguage(); ?>" dir="<?php echo currentDirection(); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php _e('create_account'); ?> - <?php echo SITE_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="min-h-screen flex items-center justify-center p-4 my-8"
      style="background: linear-gradient(135deg, #064e3b 0%, #065f46 50%, #047857 100%);">

    <div class="absolute rounded-full bg-white/5 pointer-events-none"
         style="width:300px;height:300px;top:-50px;left:-50px;"></div>
    <div class="absolute rounded-full bg-white/5 pointer-events-none"
         style="width:400px;height:400px;bottom:-100px;right:-100px;"></div>

    <div class="bg-white/98 backdrop-blur-xl rounded-3xl w-full max-w-md p-8 md:p-10 shadow-2xl relative z-10">
        <?php echo $content; ?>
        <p class="text-center text-xs text-gray-400 mt-8">
            © <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. <?php _e('all_rights_reserved'); ?>.
        </p>
    </div>

    <script src="<?php echo SITE_URL; ?>/assets/js/auth.js" defer></script>
    <script src="<?php echo SITE_URL; ?>/assets/js/main.js" defer></script>
    
    <script src="assets/js/main.js"></script>
</body>
</html>