<?php
/**
 * ZAKKATPRO - Knowledge Center
 *
 * Purpose:
 * - Public Zakat knowledge center
 * - Search and category filtering
 * - Featured articles
 * - Latest articles
 * - Quick guides
 *
 * Current stage:
 * - Frontend / static data
 * - Database-ready structure
 *
 * Future:
 * - Load articles from MySQL
 * - Admin-managed content
 * - Dynamic article pages
 */

$pageTitle = 'Knowledge Center';
?>

<?php include '../includes/header.php'; 

require_once __DIR__ . '/../logic/motivation_logic.php';
?>

<!-- =========================================================
     KNOWLEDGE PAGE
========================================================= -->

<main class="bg-white text-slate-900 dark:bg-slate-950 dark:text-slate-100">

    <!-- =====================================================
         HERO / INTRODUCTION
    ====================================================== -->
    <section class="relative overflow-hidden border-b border-slate-200 dark:border-slate-800">

        <!-- Decorative background -->
        <div class="pointer-events-none absolute inset-0">
            <div class="absolute -left-20 -top-20 h-72 w-72 rounded-full bg-emerald-100/60 blur-3xl dark:bg-emerald-900/20"></div>
            <div class="absolute -bottom-20 -right-20 h-72 w-72 rounded-full bg-amber-100/50 blur-3xl dark:bg-amber-900/10"></div>
        </div>

        <div class="relative mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-20">

            <div class="mx-auto max-w-3xl text-center">

                <!-- Eyebrow -->
                <div class="mb-5 inline-flex items-center gap-2 rounded-full border border-emerald-200 bg-emerald-50 px-4 py-2 text-sm font-semibold text-emerald-700 dark:border-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300">
                    <span class="h-2 w-2 rounded-full bg-emerald-500"></span>
                    ZAKKATPRO Knowledge Center
                </div>

                <!-- Heading -->
                <h1 class="text-4xl font-extrabold tracking-tight text-slate-950 sm:text-5xl lg:text-6xl dark:text-white">
                    Learn About
                    <span class="text-emerald-600 dark:text-emerald-400">
                        Zakat
                    </span>
                    with Clarity
                </h1>

                <!-- Description -->
                <p class="mx-auto mt-6 max-w-2xl text-base leading-8 text-slate-600 sm:text-lg dark:text-slate-300">
                    Explore clear and structured resources about Zakat,
                    including its principles, eligibility, Nisab, different
                    categories of wealth, and practical guidance.
                </p>

                <!-- Search -->
                <div class="relative mx-auto mt-9 max-w-2xl">

                    <label for="knowledgeSearch" class="sr-only">
                        Search Zakat knowledge
                    </label>

                    <div class="flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-2 shadow-lg shadow-slate-200/50 sm:flex-row dark:border-slate-700 dark:bg-slate-900 dark:shadow-black/20">

                        <div class="flex flex-1 items-center">

                            <svg
                                class="ml-3 h-5 w-5 shrink-0 text-slate-400"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="2"
                                aria-hidden="true"
                            >
                                <circle cx="11" cy="11" r="7"></circle>
                                <path d="m20 20-3.5-3.5"></path>
                            </svg>

                            <input
                                type="search"
                                id="knowledgeSearch"
                                name="knowledge_search"
                                placeholder="Search Zakat knowledge..."
                                autocomplete="off"
                                class="w-full border-0 bg-transparent px-3 py-3 text-sm text-slate-900 outline-none placeholder:text-slate-400 focus:ring-0 dark:text-white"
                            >

                        </div>

                        <button
                            type="button"
                            id="knowledgeSearchButton"
                            class="rounded-xl bg-emerald-700 px-6 py-3 text-sm font-semibold text-white transition hover:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 dark:bg-emerald-600 dark:hover:bg-emerald-500"
                        >
                            Search
                        </button>

                    </div>

                    <p class="mt-3 text-xs text-slate-500 dark:text-slate-400">
                        Search by topic, article title, category or keyword.
                    </p>

                </div>

            </div>

        </div>
    </section>


    <!-- =====================================================
         MAIN CONTENT
    ====================================================== -->
    <div class="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8 lg:py-20">


        <!-- =================================================
             FEATURED ARTICLES
        ================================================== -->
        <section aria-labelledby="featured-heading">

            <div class="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">

                <div>
                    <p class="mb-2 text-sm font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                        Featured
                    </p>

                    <h2
                        id="featured-heading"
                        class="text-3xl font-bold tracking-tight text-slate-950 dark:text-white"
                    >
                        Featured Articles
                    </h2>

                    <p class="mt-2 max-w-2xl text-sm leading-6 text-slate-600 dark:text-slate-400">
                        Start with some of the most useful topics in the ZAKKATPRO Knowledge Center.
                    </p>
                </div>

                <a
                    href="category.php"
                    class="inline-flex items-center gap-2 text-sm font-semibold text-emerald-700 transition hover:text-emerald-800 dark:text-emerald-400 dark:hover:text-emerald-300"
                >
                    View all articles

                    <svg
                        class="h-4 w-4"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        aria-hidden="true"
                    >
                        <path d="M5 12h14"></path>
                        <path d="m13 6 6 6-6 6"></path>
                    </svg>
                </a>

            </div>


            <div class="grid gap-6 lg:grid-cols-3">


                <!-- Featured Article 1 -->
                <article
                    class="knowledge-article group overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl dark:border-slate-800 dark:bg-slate-900"
                    data-category="basics"
                    data-search="what is zakat zakat basics introduction principles obligation"
                >

                    <div class="relative h-52 overflow-hidden bg-gradient-to-br from-emerald-900 to-emerald-700">

                        <div class="absolute inset-0 opacity-20">
                            <div class="absolute -right-10 -top-10 h-40 w-40 rounded-full border-[30px] border-white"></div>
                            <div class="absolute -bottom-20 -left-10 h-48 w-48 rounded-full border-[35px] border-emerald-300"></div>
                        </div>

                        <div class="relative flex h-full items-end p-6">

                            <span class="rounded-full bg-white/15 px-3 py-1 text-xs font-semibold text-white backdrop-blur">
                                Zakat Basics
                            </span>

                        </div>

                    </div>


                    <div class="p-6">

                        <div class="mb-3 flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
                            <span>Basics</span>
                            <span>•</span>
                            <span>6 min read</span>
                        </div>

                        <h3 class="text-xl font-bold text-slate-950 dark:text-white">
                            Understanding Zakat: A Complete Introduction
                        </h3>

                        <p class="mt-3 line-clamp-3 text-sm leading-6 text-slate-600 dark:text-slate-400">
                            Learn the meaning, purpose and fundamental principles
                            of Zakat and why it forms an important part of Islamic practice.
                        </p>

                        <a
                            href="article.php?slug=understanding-zakat"
                            class="mt-6 inline-flex items-center gap-2 text-sm font-bold text-emerald-700 dark:text-emerald-400"
                        >
                            Read Article

                            <svg
                                class="h-4 w-4 transition-transform group-hover:translate-x-1 rtl:rotate-180"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="2"
                                aria-hidden="true"
                            >
                                <path d="M5 12h14"></path>
                                <path d="m13 6 6 6-6 6"></path>
                            </svg>

                        </a>

                    </div>

                </article>


                <!-- Featured Article 2 -->
                <article
                    class="knowledge-article group overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl dark:border-slate-800 dark:bg-slate-900"
                    data-category="nisab"
                    data-search="nisab threshold wealth gold silver zakat"
                >

                    <div class="relative h-52 overflow-hidden bg-gradient-to-br from-amber-700 to-yellow-600">

                        <div class="absolute inset-0 opacity-20">
                            <div class="absolute left-10 top-10 h-28 w-28 rounded-full border-[22px] border-white"></div>
                            <div class="absolute -bottom-16 -right-10 h-48 w-48 rounded-full border-[30px] border-yellow-200"></div>
                        </div>

                        <div class="relative flex h-full items-end p-6">

                            <span class="rounded-full bg-white/15 px-3 py-1 text-xs font-semibold text-white backdrop-blur">
                                Nisab & Hawl
                            </span>

                        </div>

                    </div>


                    <div class="p-6">

                        <div class="mb-3 flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
                            <span>Nisab</span>
                            <span>•</span>
                            <span>7 min read</span>
                        </div>

                        <h3 class="text-xl font-bold text-slate-950 dark:text-white">
                            Understanding Nisab
                        </h3>

                        <p class="mt-3 line-clamp-3 text-sm leading-6 text-slate-600 dark:text-slate-400">
                            Explore what Nisab means, why it matters and how
                            it relates to determining Zakat obligations.
                        </p>

                        <a
                            href="article.php?slug=understanding-nisab"
                            class="mt-6 inline-flex items-center gap-2 text-sm font-bold text-emerald-700 dark:text-emerald-400"
                        >
                            Read Article

                            <svg
                                class="h-4 w-4 transition-transform group-hover:translate-x-1 rtl:rotate-180"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="2"
                                aria-hidden="true"
                            >
                                <path d="M5 12h14"></path>
                                <path d="m13 6 6 6-6 6"></path>
                            </svg>

                        </a>

                    </div>

                </article>


                <!-- Featured Article 3 -->
                <article
                    class="knowledge-article group overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl dark:border-slate-800 dark:bg-slate-900"
                    data-category="business"
                    data-search="business zakat trade assets inventory commercial wealth"
                >

                    <div class="relative h-52 overflow-hidden bg-gradient-to-br from-slate-800 to-slate-600">

                        <div class="absolute inset-0 opacity-20">
                            <div class="absolute -right-10 top-10 h-44 w-44 rounded-xl border-[25px] border-white rotate-12"></div>
                            <div class="absolute -bottom-10 left-8 h-32 w-32 rounded-full border-[20px] border-slate-300"></div>
                        </div>

                        <div class="relative flex h-full items-end p-6">

                            <span class="rounded-full bg-white/15 px-3 py-1 text-xs font-semibold text-white backdrop-blur">
                                Business Zakat
                            </span>

                        </div>

                    </div>


                    <div class="p-6">

                        <div class="mb-3 flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
                            <span>Business</span>
                            <span>•</span>
                            <span>8 min read</span>
                        </div>

                        <h3 class="text-xl font-bold text-slate-950 dark:text-white">
                            Zakat on Business Assets
                        </h3>

                        <p class="mt-3 line-clamp-3 text-sm leading-6 text-slate-600 dark:text-slate-400">
                            Understand the key concepts involved when assessing
                            Zakat related to business and commercial wealth.
                        </p>

                        <a
                            href="article.php?slug=business-zakat"
                            class="mt-6 inline-flex items-center gap-2 text-sm font-bold text-emerald-700 dark:text-emerald-400"
                        >
                            Read Article

                            <svg
                                class="h-4 w-4 transition-transform group-hover:translate-x-1 rtl:rotate-180"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="2"
                                aria-hidden="true"
                            >
                                <path d="M5 12h14"></path>
                                <path d="m13 6 6 6-6 6"></path>
                            </svg>

                        </a>

                    </div>

                </article>

            </div>

        </section>


        <!-- =================================================
             CATEGORY SECTION
        ================================================== -->
        <section
            class="mt-20"
            aria-labelledby="category-heading"
        >

            <div class="mb-8">

                <p class="mb-2 text-sm font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                    Explore
                </p>

                <h2
                    id="category-heading"
                    class="text-3xl font-bold tracking-tight text-slate-950 dark:text-white"
                >
                    Browse by Category
                </h2>

                <p class="mt-2 max-w-2xl text-sm leading-6 text-slate-600 dark:text-slate-400">
                    Find resources based on the Zakat topic you want to understand.
                </p>

            </div>


            <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">


                <!-- Category -->
                <a
                    href="category.php?category=basics"
                    class="group rounded-2xl border border-slate-200 bg-white p-6 transition duration-300 hover:-translate-y-1 hover:border-emerald-300 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900 dark:hover:border-emerald-700"
                >

                    <div class="mb-5 flex h-12 w-12 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400">
                        <span class="text-xl font-bold">01</span>
                    </div>

                    <h3 class="font-bold text-slate-950 dark:text-white">
                        Zakat Basics
                    </h3>

                    <p class="mt-2 text-sm leading-6 text-slate-500 dark:text-slate-400">
                        Learn the fundamental concepts and principles of Zakat.
                    </p>

                    <span class="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-emerald-700 dark:text-emerald-400">
                        Explore
                        <span class="transition-transform group-hover:translate-x-1">→</span>
                    </span>

                </a>


                <!-- Category -->
                <a
                    href="category.php?category=wealth"
                    class="group rounded-2xl border border-slate-200 bg-white p-6 transition duration-300 hover:-translate-y-1 hover:border-emerald-300 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900 dark:hover:border-emerald-700"
                >

                    <div class="mb-5 flex h-12 w-12 items-center justify-center rounded-xl bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-400">
                        <span class="text-xl font-bold">02</span>
                    </div>

                    <h3 class="font-bold text-slate-950 dark:text-white">
                        Zakat on Wealth
                    </h3>

                    <p class="mt-2 text-sm leading-6 text-slate-500 dark:text-slate-400">
                        Explore how different forms of wealth relate to Zakat.
                    </p>

                    <span class="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-emerald-700 dark:text-emerald-400">
                        Explore
                        <span class="transition-transform group-hover:translate-x-1">→</span>
                    </span>

                </a>


                <!-- Category -->
                <a
                    href="category.php?category=cash"
                    class="group rounded-2xl border border-slate-200 bg-white p-6 transition duration-300 hover:-translate-y-1 hover:border-emerald-300 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900 dark:hover:border-emerald-700"
                >

                    <div class="mb-5 flex h-12 w-12 items-center justify-center rounded-xl bg-violet-100 text-violet-700 dark:bg-violet-950 dark:text-violet-400">
                        <span class="text-xl font-bold">03</span>
                    </div>

                    <h3 class="font-bold text-slate-950 dark:text-white">
                        Cash & Savings
                    </h3>

                    <p class="mt-2 text-sm leading-6 text-slate-500 dark:text-slate-400">
                        Understand Zakat related to money, savings and cash holdings.
                    </p>

                    <span class="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-emerald-700 dark:text-emerald-400">
                        Explore
                        <span class="transition-transform group-hover:translate-x-1">→</span>
                    </span>

                </a>


                <!-- Category -->
                <a
                    href="category.php?category=gold-silver"
                    class="group rounded-2xl border border-slate-200 bg-white p-6 transition duration-300 hover:-translate-y-1 hover:border-emerald-300 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900 dark:hover:border-emerald-700"
                >

                    <div class="mb-5 flex h-12 w-12 items-center justify-center rounded-xl bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400">
                        <span class="text-xl font-bold">04</span>
                    </div>

                    <h3 class="font-bold text-slate-950 dark:text-white">
                        Gold & Silver
                    </h3>

                    <p class="mt-2 text-sm leading-6 text-slate-500 dark:text-slate-400">
                        Explore important concepts relating to gold, silver and Nisab.
                    </p>

                    <span class="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-emerald-700 dark:text-emerald-400">
                        Explore
                        <span class="transition-transform group-hover:translate-x-1">→</span>
                    </span>

                </a>


                <!-- Category -->
                <a
                    href="category.php?category=business"
                    class="group rounded-2xl border border-slate-200 bg-white p-6 transition duration-300 hover:-translate-y-1 hover:border-emerald-300 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900 dark:hover:border-emerald-700"
                >

                    <div class="mb-5 flex h-12 w-12 items-center justify-center rounded-xl bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                        <span class="text-xl font-bold">05</span>
                    </div>

                    <h3 class="font-bold text-slate-950 dark:text-white">
                        Business Zakat
                    </h3>

                    <p class="mt-2 text-sm leading-6 text-slate-500 dark:text-slate-400">
                        Learn about Zakat considerations for business and trade.
                    </p>

                    <span class="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-emerald-700 dark:text-emerald-400">
                        Explore
                        <span class="transition-transform group-hover:translate-x-1">→</span>
                    </span>

                </a>


                <!-- Category -->
                <a
                    href="category.php?category=agriculture"
                    class="group rounded-2xl border border-slate-200 bg-white p-6 transition duration-300 hover:-translate-y-1 hover:border-emerald-300 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900 dark:hover:border-emerald-700"
                >

                    <div class="mb-5 flex h-12 w-12 items-center justify-center rounded-xl bg-lime-100 text-lime-700 dark:bg-lime-950 dark:text-lime-400">
                        <span class="text-xl font-bold">06</span>
                    </div>

                    <h3 class="font-bold text-slate-950 dark:text-white">
                        Agriculture
                    </h3>

                    <p class="mt-2 text-sm leading-6 text-slate-500 dark:text-slate-400">
                        Learn about agricultural produce and its Zakat considerations.
                    </p>

                    <span class="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-emerald-700 dark:text-emerald-400">
                        Explore
                        <span class="transition-transform group-hover:translate-x-1">→</span>
                    </span>

                </a>


                <!-- Category -->
                <a
                    href="category.php?category=livestock"
                    class="group rounded-2xl border border-slate-200 bg-white p-6 transition duration-300 hover:-translate-y-1 hover:border-emerald-300 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900 dark:hover:border-emerald-700"
                >

                    <div class="mb-5 flex h-12 w-12 items-center justify-center rounded-xl bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-400">
                        <span class="text-xl font-bold">07</span>
                    </div>

                    <h3 class="font-bold text-slate-950 dark:text-white">
                        Livestock
                    </h3>

                    <p class="mt-2 text-sm leading-6 text-slate-500 dark:text-slate-400">
                        Explore Zakat topics related to livestock and animals.
                    </p>

                    <span class="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-emerald-700 dark:text-emerald-400">
                        Explore
                        <span class="transition-transform group-hover:translate-x-1">→</span>
                    </span>

                </a>


                <!-- Category -->
                <a
                    href="category.php?category=fiqh"
                    class="group rounded-2xl border border-slate-200 bg-white p-6 transition duration-300 hover:-translate-y-1 hover:border-emerald-300 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900 dark:hover:border-emerald-700"
                >

                    <div class="mb-5 flex h-12 w-12 items-center justify-center rounded-xl bg-cyan-100 text-cyan-700 dark:bg-cyan-950 dark:text-cyan-400">
                        <span class="text-xl font-bold">08</span>
                    </div>

                    <h3 class="font-bold text-slate-950 dark:text-white">
                        Fiqh & Methodology
                    </h3>

                    <p class="mt-2 text-sm leading-6 text-slate-500 dark:text-slate-400">
                        Explore the scholarly and methodological foundations used by ZAKKATPRO.
                    </p>

                    <span class="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-emerald-700 dark:text-emerald-400">
                        Explore
                        <span class="transition-transform group-hover:translate-x-1">→</span>
                    </span>

                </a>

            </div>

        </section>


        <!-- =================================================
             LATEST ARTICLES
        ================================================== -->
        <section
            class="mt-20"
            aria-labelledby="latest-heading"
        >

            <div class="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">

                <div>

                    <p class="mb-2 text-sm font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                        Knowledge
                    </p>

                    <h2
                        id="latest-heading"
                        class="text-3xl font-bold tracking-tight text-slate-950 dark:text-white"
                    >
                        Latest Articles
                    </h2>

                    <p class="mt-2 max-w-2xl text-sm leading-6 text-slate-600 dark:text-slate-400">
                        Continue learning with more topics from the Knowledge Center.
                    </p>

                </div>

                <a
                    href="category.php"
                    class="inline-flex items-center gap-2 text-sm font-semibold text-emerald-700 dark:text-emerald-400"
                >
                    View all
                    <span>→</span>
                </a>

            </div>


            <div
                id="articleGrid"
                class="grid gap-6 md:grid-cols-2 lg:grid-cols-3"
            >

                <!-- Article -->
                <article
                    class="knowledge-article group rounded-2xl border border-slate-200 bg-white p-6 transition duration-300 hover:-translate-y-1 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900"
                    data-category="basics"
                    data-search="who must pay zakat eligibility conditions"
                >

                    <div class="mb-5 flex items-center justify-between">

                        <span class="rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400">
                            Zakat Basics
                        </span>

                        <span class="text-xs text-slate-400">
                            5 min read
                        </span>

                    </div>

                    <h3 class="text-lg font-bold text-slate-950 dark:text-white">
                        Who Must Pay Zakat?
                    </h3>

                    <p class="mt-3 text-sm leading-6 text-slate-600 dark:text-slate-400">
                        Explore the basic considerations surrounding Zakat obligation and eligibility.
                    </p>

                    <a
                        href="article.php?slug=who-must-pay-zakat"
                        class="mt-5 inline-flex items-center text-sm font-bold text-emerald-700 dark:text-emerald-400"
                    >
                        Read Article →
                    </a>

                </article>


                <!-- Article -->
                <article
                    class="knowledge-article group rounded-2xl border border-slate-200 bg-white p-6 transition duration-300 hover:-translate-y-1 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900"
                    data-category="nisab"
                    data-search="hawl nisab year zakat period"
                >

                    <div class="mb-5 flex items-center justify-between">

                        <span class="rounded-full bg-amber-50 px-3 py-1 text-xs font-semibold text-amber-700 dark:bg-amber-950 dark:text-amber-400">
                            Nisab & Hawl
                        </span>

                        <span class="text-xs text-slate-400">
                            6 min read
                        </span>

                    </div>

                    <h3 class="text-lg font-bold text-slate-950 dark:text-white">
                        Understanding Hawl
                    </h3>

                    <p class="mt-3 text-sm leading-6 text-slate-600 dark:text-slate-400">
                        Learn about the concept of Hawl and its relationship with Zakat on qualifying wealth.
                    </p>

                    <a
                        href="article.php?slug=understanding-hawl"
                        class="mt-5 inline-flex items-center text-sm font-bold text-emerald-700 dark:text-emerald-400"
                    >
                        Read Article →
                    </a>

                </article>


                <!-- Article -->
                <article
                    class="knowledge-article group rounded-2xl border border-slate-200 bg-white p-6 transition duration-300 hover:-translate-y-1 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900"
                    data-category="cash"
                    data-search="cash savings money zakat wealth"
                >

                    <div class="mb-5 flex items-center justify-between">

                        <span class="rounded-full bg-violet-50 px-3 py-1 text-xs font-semibold text-violet-700 dark:bg-violet-950 dark:text-violet-400">
                            Cash & Savings
                        </span>

                        <span class="text-xs text-slate-400">
                            7 min read
                        </span>

                    </div>

                    <h3 class="text-lg font-bold text-slate-950 dark:text-white">
                        Zakat on Cash & Savings
                    </h3>

                    <p class="mt-3 text-sm leading-6 text-slate-600 dark:text-slate-400">
                        Understand the basic concepts involved when considering Zakat on money and savings.
                    </p>

                    <a
                        href="article.php?slug=zakat-on-cash-and-savings"
                        class="mt-5 inline-flex items-center text-sm font-bold text-emerald-700 dark:text-emerald-400"
                    >
                        Read Article →
                    </a>

                </article>


                <!-- Article -->
                <article
                    class="knowledge-article group rounded-2xl border border-slate-200 bg-white p-6 transition duration-300 hover:-translate-y-1 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900"
                    data-category="gold-silver"
                    data-search="gold silver zakat nisab jewelry"
                >

                    <div class="mb-5 flex items-center justify-between">

                        <span class="rounded-full bg-yellow-50 px-3 py-1 text-xs font-semibold text-yellow-700 dark:bg-yellow-950 dark:text-yellow-400">
                            Gold & Silver
                        </span>

                        <span class="text-xs text-slate-400">
                            8 min read
                        </span>

                    </div>

                    <h3 class="text-lg font-bold text-slate-950 dark:text-white">
                        Zakat on Gold & Silver
                    </h3>

                    <p class="mt-3 text-sm leading-6 text-slate-600 dark:text-slate-400">
                        Explore key considerations related to gold, silver and their role in Nisab assessment.
                    </p>

                    <a
                        href="article.php?slug=zakat-on-gold-and-silver"
                        class="mt-5 inline-flex items-center text-sm font-bold text-emerald-700 dark:text-emerald-400"
                    >
                        Read Article →
                    </a>

                </article>


                <!-- Article -->
                <article
                    class="knowledge-article group rounded-2xl border border-slate-200 bg-white p-6 transition duration-300 hover:-translate-y-1 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900"
                    data-category="agriculture"
                    data-search="agriculture crops harvest zakat produce farming"
                >

                    <div class="mb-5 flex items-center justify-between">

                        <span class="rounded-full bg-lime-50 px-3 py-1 text-xs font-semibold text-lime-700 dark:bg-lime-950 dark:text-lime-400">
                            Agriculture
                        </span>

                        <span class="text-xs text-slate-400">
                            9 min read
                        </span>

                    </div>

                    <h3 class="text-lg font-bold text-slate-950 dark:text-white">
                        Zakat on Agricultural Produce
                    </h3>

                    <p class="mt-3 text-sm leading-6 text-slate-600 dark:text-slate-400">
                        Explore agricultural Zakat concepts and the factors that may affect its assessment.
                    </p>

                    <a
                        href="article.php?slug=zakat-on-agriculture"
                        class="mt-5 inline-flex items-center text-sm font-bold text-emerald-700 dark:text-emerald-400"
                    >
                        Read Article →
                    </a>

                </article>


                <!-- Article -->
                <article
                    class="knowledge-article group rounded-2xl border border-slate-200 bg-white p-6 transition duration-300 hover:-translate-y-1 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900"
                    data-category="fiqh"
                    data-search="fiqh methodology madhhab zakat sources references"
                >

                    <div class="mb-5 flex items-center justify-between">

                        <span class="rounded-full bg-cyan-50 px-3 py-1 text-xs font-semibold text-cyan-700 dark:bg-cyan-950 dark:text-cyan-400">
                            Fiqh & Methodology
                        </span>

                        <span class="text-xs text-slate-400">
                            10 min read
                        </span>

                    </div>

                    <h3 class="text-lg font-bold text-slate-950 dark:text-white">
                        Zakat: Fiqh & Methodology
                    </h3>

                    <p class="mt-3 text-sm leading-6 text-slate-600 dark:text-slate-400">
                        Understand how scholarly references and methodology can be organized within ZAKKATPRO.
                    </p>

                    <a
                        href="article.php?slug=fiqh-and-methodology"
                        class="mt-5 inline-flex items-center text-sm font-bold text-emerald-700 dark:text-emerald-400"
                    >
                        Read Article →
                    </a>

                </article>

            </div>


            <!-- No results -->
            <div
                id="noArticleResults"
                class="hidden py-16 text-center"
            >

                <div class="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-slate-100 dark:bg-slate-800">
                    <svg
                        class="h-7 w-7 text-slate-400"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        aria-hidden="true"
                    >
                        <circle cx="11" cy="11" r="7"></circle>
                        <path d="m20 20-3.5-3.5"></path>
                    </svg>
                </div>

                <h3 class="mt-5 text-lg font-bold text-slate-900 dark:text-white">
                    No articles found
                </h3>

                <p class="mx-auto mt-2 max-w-md text-sm text-slate-500 dark:text-slate-400">
                    We couldn't find an article matching your search.
                    Try another keyword or browse our categories.
                </p>

            </div>

        </section>


        <!-- =================================================
             QUICK GUIDES
        ================================================== -->
        <section class="mt-20">

            <div class="rounded-3xl bg-slate-50 p-6 sm:p-8 lg:p-10 dark:bg-slate-900/70">

                <div class="grid gap-10 lg:grid-cols-[0.8fr_1.2fr] lg:items-center">

                    <div>

                        <p class="mb-2 text-sm font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
                            Quick Guides
                        </p>

                        <h2 class="text-3xl font-bold tracking-tight text-slate-950 dark:text-white">
                            Start with the essentials
                        </h2>

                        <p class="mt-4 text-sm leading-7 text-slate-600 dark:text-slate-400">
                            If you are new to Zakat, these guides can help you
                            understand the basic concepts before moving to calculation.
                        </p>

                    </div>


                    <div class="grid gap-3 sm:grid-cols-2">

                        <a
                            href="article.php?slug=understanding-zakat"
                            class="group flex items-center justify-between rounded-xl border border-slate-200 bg-white p-4 transition hover:border-emerald-300 hover:shadow-sm dark:border-slate-700 dark:bg-slate-800 dark:hover:border-emerald-700"
                        >
                            <span class="text-sm font-semibold text-slate-800 dark:text-slate-200">
                                What is Zakat?
                            </span>

                            <span class="text-emerald-600 transition-transform group-hover:translate-x-1 dark:text-emerald-400">
                                →
                            </span>
                        </a>


                        <a
                            href="article.php?slug=understanding-nisab"
                            class="group flex items-center justify-between rounded-xl border border-slate-200 bg-white p-4 transition hover:border-emerald-300 hover:shadow-sm dark:border-slate-700 dark:bg-slate-800 dark:hover:border-emerald-700"
                        >
                            <span class="text-sm font-semibold text-slate-800 dark:text-slate-200">
                                Understanding Nisab
                            </span>

                            <span class="text-emerald-600 transition-transform group-hover:translate-x-1 dark:text-emerald-400">
                                →
                            </span>
                        </a>


                        <a
                            href="article.php?slug=who-must-pay-zakat"
                            class="group flex items-center justify-between rounded-xl border border-slate-200 bg-white p-4 transition hover:border-emerald-300 hover:shadow-sm dark:border-slate-700 dark:bg-slate-800 dark:hover:border-emerald-700"
                        >
                            <span class="text-sm font-semibold text-slate-800 dark:text-slate-200">
                                Who Must Pay Zakat?
                            </span>

                            <span class="text-emerald-600 transition-transform group-hover:translate-x-1 dark:text-emerald-400">
                                →
                            </span>
                        </a>


                        <a
                            href="article.php?slug=zakat-on-cash-and-savings"
                            class="group flex items-center justify-between rounded-xl border border-slate-200 bg-white p-4 transition hover:border-emerald-300 hover:shadow-sm dark:border-slate-700 dark:bg-slate-800 dark:hover:border-emerald-700"
                        >
                            <span class="text-sm font-semibold text-slate-800 dark:text-slate-200">
                                Zakat on Cash
                            </span>

                            <span class="text-emerald-600 transition-transform group-hover:translate-x-1 dark:text-emerald-400">
                                →
                            </span>
                        </a>

                    </div>

                </div>

            </div>

        </section>


        <!-- =================================================
             FATWA CONNECTION
        ================================================== -->
        <section class="mt-16">

            <div class="overflow-hidden rounded-3xl border border-emerald-200 bg-emerald-50 dark:border-emerald-900 dark:bg-emerald-950/30">

                <div class="grid lg:grid-cols-[1fr_auto] lg:items-center">

                    <div class="p-7 sm:p-10">

                        <span class="text-sm font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400">
                            Need More Guidance?
                        </span>

                        <h2 class="mt-3 text-2xl font-bold text-slate-950 sm:text-3xl dark:text-white">
                            Still have a Zakat question?
                        </h2>

                        <p class="mt-3 max-w-2xl text-sm leading-7 text-slate-600 dark:text-slate-300">
                            Explore published questions and answers, or submit
                            a question for review through the ZAKKATPRO Fatwa section.
                        </p>

                    </div>


                    <div class="flex flex-col gap-3 p-7 sm:flex-row lg:p-10">

                        <a
                            href="../fatwa/index.php"
                            class="inline-flex items-center justify-center rounded-xl bg-emerald-700 px-5 py-3 text-sm font-bold text-white transition hover:bg-emerald-800 dark:bg-emerald-600 dark:hover:bg-emerald-500"
                        >
                            Explore Fatwa
                        </a>

                        <a
                            href="../fatwa/submit.php"
                            class="inline-flex items-center justify-center rounded-xl border border-emerald-300 bg-white px-5 py-3 text-sm font-bold text-emerald-800 transition hover:bg-emerald-50 dark:border-emerald-700 dark:bg-transparent dark:text-emerald-300 dark:hover:bg-emerald-950"
                        >
                            Ask a Question
                        </a>

                    </div>

                </div>

            </div>

        </section>


        <!-- =================================================
             CALCULATOR CTA
        ================================================== -->
        <section class="mt-10">

            <div class="relative overflow-hidden rounded-3xl bg-emerald-900 px-7 py-12 text-center sm:px-10 lg:py-14">

                <!-- Decorative elements -->
                <div class="pointer-events-none absolute -left-20 -top-20 h-60 w-60 rounded-full border-[35px] border-white/5"></div>
                <div class="pointer-events-none absolute -bottom-28 -right-16 h-72 w-72 rounded-full border-[45px] border-amber-300/10"></div>

                <div class="relative mx-auto max-w-3xl">

                    <p class="text-sm font-bold uppercase tracking-widest text-emerald-300">
                        Ready to continue?
                    </p>

                    <h2 class="mt-3 text-3xl font-bold tracking-tight text-white sm:text-4xl">
                        Understand your Zakat.
                        Then calculate with confidence.
                    </h2>

                    <p class="mx-auto mt-4 max-w-2xl text-sm leading-7 text-emerald-100">
                        When you are ready, use the ZAKKATPRO calculator
                        to begin your Zakat assessment.
                    </p>

                    <a
                        href="../calculator/index.php"
                        class="mt-7 inline-flex items-center justify-center gap-2 rounded-xl bg-white px-6 py-3.5 text-sm font-bold text-emerald-900 shadow-lg transition hover:bg-emerald-50"
                    >
                        Calculate Zakat

                        <svg
                            class="h-4 w-4"
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            stroke-width="2"
                            aria-hidden="true"
                        >
                            <path d="M5 12h14"></path>
                            <path d="m13 6 6 6-6 6"></path>
                        </svg>

                    </a>

                </div>

            </div>

        </section>

    </div>

</main>


<!-- =========================================================
     KNOWLEDGE PAGE SEARCH SCRIPT
     Page-specific behavior only.
     Global features remain inside assets/js/main.js
========================================================= -->

<script>
document.addEventListener("DOMContentLoaded", function () {

    const searchInput = document.getElementById("knowledgeSearch");
    const searchButton = document.getElementById("knowledgeSearchButton");
    const articles = document.querySelectorAll(".knowledge-article");
    const noResults = document.getElementById("noArticleResults");

    if (!searchInput || !articles.length) {
        return;
    }

    function normalize(value) {
        return value
            .toLowerCase()
            .trim()
            .replace(/\s+/g, " ");
    }

    function performSearch() {

        const query = normalize(searchInput.value);

        let visibleArticles = 0;

        articles.forEach(function (article) {

            const searchableText = normalize(
                (article.textContent || "") +
                " " +
                (article.dataset.search || "")
            );

            const matches = query === "" || searchableText.includes(query);

            if (matches) {
                article.classList.remove("hidden");
                visibleArticles++;
            } else {
                article.classList.add("hidden");
            }

        });

        if (noResults) {
            if (visibleArticles === 0) {
                noResults.classList.remove("hidden");
            } else {
                noResults.classList.add("hidden");
            }
        }

    }

    searchInput.addEventListener("input", performSearch);

    if (searchButton) {
        searchButton.addEventListener("click", performSearch);
    }

    searchInput.addEventListener("keydown", function (event) {

        if (event.key === "Enter") {
            event.preventDefault();
            performSearch();
        }

    });

});
</script>


<?php include '../includes/footer.php'; ?>