<?php

/**
 * Agriculture Zakat Calculator
 *
 * UI + server-side calculation connection.
 * Calculation logic:
 * ../../Logic/agriculture_logic.php
 */

require_once __DIR__ . '/../../Logic/agriculture_logic.php';

/*
|--------------------------------------------------------------------------
| Default Values
|--------------------------------------------------------------------------
*/

$result = null;
$unitLabel = 'unit';

/*
|--------------------------------------------------------------------------
| Handle Form Submission
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $amount = isset($_POST['harvest_amount'])
        ? (float) $_POST['harvest_amount']
        : 0;

    $unit = $_POST['measurement_unit'] ?? '';

    $irrigation = $_POST['irrigation'] ?? '';

    $customWeight = isset($_POST['custom_weight'])
        ? (float) $_POST['custom_weight']
        : 0;

    /*
    |--------------------------------------------------------------------------
    | Unit Label
    |--------------------------------------------------------------------------
    */

    $unitLabel = match ($unit) {
        'kg' => 'kg',
        'bag50' => '50kg bag',
        'bag100' => '100kg bag',
        'ton' => 'metric ton',
        'custom' => 'custom unit',
        default => 'unit'
    };

    /*
    |--------------------------------------------------------------------------
    | Run Agriculture Calculation
    |--------------------------------------------------------------------------
    */

    $result = calculateAgricultureZakat(
        $amount,
        $unit,
        $irrigation,
        $customWeight
    );
}

?>

<div class="max-w-4xl mx-auto">

    <!-- Header -->
    <div class="mb-6">

        <div class="flex items-center gap-3 mb-2">

            <div class="w-11 h-11 rounded-xl bg-green-100 flex items-center justify-center">
                <i class="fa-solid fa-seedling text-green-700 text-xl"></i>
            </div>

            <div>
                <h1 class="text-2xl font-bold text-gray-800">
                    Agriculture Zakat Calculator
                </h1>

                <p class="text-sm text-gray-500">
                    Calculate Zakat due on your agricultural harvest.
                </p>
            </div>

        </div>

    </div>


    <!-- Calculator Card -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">

        <form method="POST" id="agricultureForm">

            <!-- Harvest Amount -->
            <div class="mb-5">

                <label class="block text-sm font-semibold text-gray-700 mb-2">
                    Harvest Amount
                </label>

                <div class="relative">

                    <input
                        type="number"
                        name="harvest_amount"
                        id="harvestAmount"
                        min="0"
                        step="0.01"
                        value="<?= htmlspecialchars($_POST['harvest_amount'] ?? '') ?>"
                        placeholder="Enter harvest amount"
                        class="w-full border border-gray-300 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500"
                        required
                    >

                </div>

            </div>


            <!-- Measurement Unit -->
            <div class="mb-5">

                <label class="block text-sm font-semibold text-gray-700 mb-2">
                    Measurement Unit
                </label>

                <select
                    name="measurement_unit"
                    id="measurementUnit"
                    class="w-full border border-gray-300 rounded-xl px-4 py-3 bg-white focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    required
                >

                    <option value="">
                        Select measurement unit
                    </option>

                    <option
                        value="kg"
                        <?= (($_POST['measurement_unit'] ?? '') === 'kg') ? 'selected' : '' ?>
                    >
                        Kilogram (kg)
                    </option>

                    <option
                        value="bag50"
                        <?= (($_POST['measurement_unit'] ?? '') === 'bag50') ? 'selected' : '' ?>
                    >
                        50kg Bag
                    </option>

                    <option
                        value="bag100"
                        <?= (($_POST['measurement_unit'] ?? '') === 'bag100') ? 'selected' : '' ?>
                    >
                        100kg Bag
                    </option>

                    <option
                        value="ton"
                        <?= (($_POST['measurement_unit'] ?? '') === 'ton') ? 'selected' : '' ?>
                    >
                        Metric Ton
                    </option>

                    <option
                        value="custom"
                        <?= (($_POST['measurement_unit'] ?? '') === 'custom') ? 'selected' : '' ?>
                    >
                        Custom Local Unit
                    </option>

                </select>

            </div>


            <!-- Custom Measurement -->
            <div
                id="customMeasurement"
                class="<?= (($_POST['measurement_unit'] ?? '') === 'custom') ? '' : 'hidden' ?> mb-5"
            >

                <label class="block text-sm font-semibold text-gray-700 mb-2">
                    Weight of One Local Unit
                </label>

                <div class="relative">

                    <input
                        type="number"
                        name="custom_weight"
                        id="customWeight"
                        min="0"
                        step="0.01"
                        value="<?= htmlspecialchars($_POST['custom_weight'] ?? '') ?>"
                        placeholder="Example: 75"
                        class="w-full border border-gray-300 rounded-xl px-4 py-3 pr-16 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    >

                    <span class="absolute right-4 top-1/2 -translate-y-1/2 text-sm text-gray-500">
                        kg
                    </span>

                </div>

                <p class="text-xs text-gray-500 mt-2">
                    Enter the approximate weight in kilograms for one of your local units.
                </p>

            </div>


            <!-- Conversion Preview -->
            <div
                id="conversionPreview"
                class="hidden mb-5 rounded-xl bg-green-50 border border-green-100 p-4"
            >

                <div class="flex items-center gap-3">

                    <div class="w-9 h-9 rounded-lg bg-green-100 flex items-center justify-center">

                        <i class="fa-solid fa-scale-balanced text-green-700"></i>

                    </div>

                    <div>

                        <p class="text-xs text-gray-500">
                            Converted Harvest
                        </p>

                        <p
                            id="convertedWeight"
                            class="text-lg font-bold text-green-700"
                        >
                            0 kg
                        </p>

                    </div>

                </div>

            </div>


            <!-- Irrigation Method -->
            <div class="mb-6">

                <label class="block text-sm font-semibold text-gray-700 mb-2">
                    Irrigation Method
                </label>

                <select
                    name="irrigation"
                    id="irrigation"
                    class="w-full border border-gray-300 rounded-xl px-4 py-3 bg-white focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    required
                >

                    <option value="">
                        Select irrigation method
                    </option>

                    <option
                        value="rain"
                        <?= (($_POST['irrigation'] ?? '') === 'rain') ? 'selected' : '' ?>
                    >
                        Natural / Rain-fed
                    </option>

                    <option
                        value="artificial"
                        <?= (($_POST['irrigation'] ?? '') === 'artificial') ? 'selected' : '' ?>
                    >
                        Artificial Irrigation
                    </option>

                    <option
                        value="mixed"
                        <?= (($_POST['irrigation'] ?? '') === 'mixed') ? 'selected' : '' ?>
                    >
                        Mixed Irrigation
                    </option>

                </select>

            </div>


            <!-- Buttons -->
            <div class="flex flex-col sm:flex-row gap-3">

                <button
                    type="submit"
                    class="flex-1 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-xl px-5 py-3 transition"
                >

                    <i class="fa-solid fa-calculator mr-2"></i>

                    Calculate Zakat

                </button>


                <button
                    type="reset"
                    id="resetAgriculture"
                    class="sm:w-32 border border-gray-300 hover:bg-gray-50 text-gray-700 font-semibold rounded-xl px-5 py-3 transition"
                >

                    Reset

                </button>

            </div>

        </form>

    </div>


    <!-- Result -->
    <?php if ($result !== null): ?>

        <div
            id="agricultureResult"
            tabindex="-1"
            class="mt-6 scroll-mt-6"
        >

            <?php if ($result['success'] === true): ?>

                <div
                    class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden"
                >

                    <!-- Result Header -->
                    <div class="p-6 border-b border-gray-100">

                        <?php if ($result['eligible']): ?>

                            <div class="flex items-center gap-3">

                                <div class="w-11 h-11 rounded-full bg-green-100 flex items-center justify-center">

                                    <i class="fa-solid fa-circle-check text-green-600 text-xl"></i>

                                </div>

                                <div>

                                    <h2 class="text-xl font-bold text-gray-800">
                                        Zakat is Due
                                    </h2>

                                    <p class="text-sm text-gray-500">
                                        Your harvest has reached the required threshold.
                                    </p>

                                </div>

                            </div>

                        <?php else: ?>

                            <div class="flex items-center gap-3">

                                <div class="w-11 h-11 rounded-full bg-yellow-100 flex items-center justify-center">

                                    <i class="fa-solid fa-circle-info text-yellow-600 text-xl"></i>

                                </div>

                                <div>

                                    <h2 class="text-xl font-bold text-gray-800">
                                        No Zakat Due
                                    </h2>

                                    <p class="text-sm text-gray-500">
                                        Your harvest has not reached the required threshold.
                                    </p>

                                </div>

                            </div>

                        <?php endif; ?>

                    </div>


                    <!-- Main Result -->
                    <div class="p-6">

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">

                            <!-- Total Harvest -->
                            <div class="rounded-xl bg-gray-50 p-4">

                                <p class="text-xs text-gray-500 mb-1">
                                    Total Harvest
                                </p>

                                <p class="text-2xl font-bold text-gray-800">

                                    <?= number_format($result['total_kg'], 2) ?>

                                    <span class="text-sm font-medium text-gray-500">
                                        kg
                                    </span>

                                </p>

                            </div>


                            <!-- Nisab -->
                            <div class="rounded-xl bg-gray-50 p-4">

                                <p class="text-xs text-gray-500 mb-1">
                                    Agricultural Nisab
                                </p>

                                <p class="text-2xl font-bold text-gray-800">

                                    <?= number_format($result['nisab_kg'], 2) ?>

                                    <span class="text-sm font-medium text-gray-500">
                                        kg
                                    </span>

                                </p>

                            </div>


                            <?php if ($result['eligible']): ?>

                                <!-- Zakat -->
                                <div class="rounded-xl bg-green-50 border border-green-100 p-4">

                                    <p class="text-xs text-green-700 mb-1">
                                        Zakat Due
                                    </p>

                                    <p class="text-2xl font-bold text-green-700">

                                        <?= number_format($result['zakat_display'], 2) ?>

                                        <span class="text-sm font-medium">

                                            <?= htmlspecialchars($unitLabel) ?>

                                        </span>

                                    </p>

                                </div>


                                <!-- Rate -->
                                <div class="rounded-xl bg-green-50 border border-green-100 p-4">

                                    <p class="text-xs text-green-700 mb-1">
                                        Zakat Rate
                                    </p>

                                    <p class="text-lg font-bold text-green-700">

                                        <?= htmlspecialchars($result['rate_label']) ?>

                                    </p>

                                </div>

                            <?php endif; ?>

                        </div>


                        <!-- Message -->
                        <div class="mt-5 rounded-xl bg-gray-50 p-4">

                            <div class="flex items-start gap-3">

                                <i class="fa-solid fa-circle-info text-gray-500 mt-1"></i>

                                <p class="text-sm text-gray-600">

                                    <?= htmlspecialchars($result['message']) ?>

                                </p>

                            </div>

                        </div>

                    </div>

                </div>

            <?php else: ?>

                <!-- Error -->
                <div class="bg-red-50 border border-red-100 rounded-2xl p-5">

                    <div class="flex items-start gap-3">

                        <div class="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center">

                            <i class="fa-solid fa-circle-exclamation text-red-600"></i>

                        </div>

                        <div>

                            <h3 class="font-semibold text-red-700">
                                Calculation Error
                            </h3>

                            <p class="text-sm text-red-600 mt-1">

                                <?= htmlspecialchars($result['message']) ?>

                            </p>

                        </div>

                    </div>

                </div>

            <?php endif; ?>

        </div>

    <?php endif; ?>

</div>