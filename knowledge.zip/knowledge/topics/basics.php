<h2 class="text-xl font-semibold text-green-700 mb-4">
    What is Zakat?
</h2>

<p class="text-gray-700 mb-4 leading-relaxed">
    Zakat is one of the five pillars of Islam. It is a mandatory charity
    that purifies wealth and supports the needy.
</p>

<!-- QURAN BLOCK -->
<div class="bg-green-50 border-l-4 border-green-600 p-4 rounded mb-6">
    <p class="italic text-green-800">
        “Take from their wealth a charity by which you purify them...”
        (Qur’an 9:103)
    </p>
</div>

<!-- PURPOSE -->
<h3 class="font-semibold text-gray-800 mb-2">
    Purpose of Zakat
</h3>

<ul class="list-disc pl-6 text-gray-700 mb-6">
    <li>Purifies wealth</li>
    <li>Helps the poor</li>
    <li>Strengthens the Ummah</li>
</ul>

<!-- NOTE BOX -->
<div class="bg-yellow-50 border-l-4 border-yellow-500 p-4 rounded">
    <p class="text-yellow-800 text-sm">
        Note: Zakat becomes obligatory only when wealth reaches Nisab and completes one lunar year.
    </p>
</div>